const events = [
  { name: "Gardening", type: "Outdoor" },
  { name: "Tech Talk", type: "Education" }
];

const cloneEvents = [...events];
const display = document.getElementById("output");
cloneEvents.forEach(({ name, type }) => {
  const li = document.createElement("li");
  li.textContent = `${name} [${type}]`;
  display.appendChild(li);
});