document.getElementById("registrationForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const name = this.name.value.trim();
  const email = this.email.value.trim();
  const event = this.event.value;
  if (!name || !email) {
    document.getElementById("message").textContent = "Please fill out all required fields.";
    return;
  }
  document.getElementById("message").textContent = `Thanks, ${name}, you registered for ${event}!`;
});