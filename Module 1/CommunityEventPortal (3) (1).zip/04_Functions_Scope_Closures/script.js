const events = [
  { name: "Music Night", category: "Music", seats: 10 },
  { name: "Yoga Session", category: "Health", seats: 5 },
  { name: "Beach Cleanup", category: "Environment", seats: 15 }
];

function createEventCard(event, index) {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <h3>${event.name}</h3>
    <p>Category: ${event.category}</p>
    <p>Seats Left: <span id="seats-${index}">${event.seats}</span></p>
    <button id="btn-${index}" ${event.seats === 0 ? "disabled" : ""}>Register</button>
  `;
  card.querySelector("button").onclick = () => registerUser(index);
  return card;
}

function displayEvents(filter = "All") {
  const container = document.getElementById("eventsContainer");
  container.innerHTML = "";
  events
    .filter(e => filter === "All" || e.category === filter)
    .forEach((e, i) => container.appendChild(createEventCard(e, i)));
}

function registerUser(index) {
  try {
    if (events[index].seats > 0) {
      events[index].seats--;
      document.getElementById(`seats-${index}`).innerText = events[index].seats;
      if (events[index].seats === 0) {
        document.getElementById(`btn-${index}`).disabled = true;
      }
    }
  } catch (err) {
    console.error("Registration failed:", err);
  }
}

// Closure example
const registrationCounter = (() => {
  let total = 0;
  return () => ++total;
})();

// Track and log total registrations
document.querySelector("#eventsContainer").addEventListener("click", (e) => {
  if (e.target.tagName === "BUTTON") {
    console.log("Total registrations:", registrationCounter());
  }
});

document.getElementById("categoryFilter").onchange = (e) => {
  displayEvents(e.target.value);
};

window.onload = () => displayEvents();