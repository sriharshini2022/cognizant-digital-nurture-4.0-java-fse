const events = [
  { name: "Jazz Night", category: "Music" },
  { name: "Wellness Workshop", category: "Health" },
  { name: "Rock Concert", category: "Music" }
];

function renderEvents(filter = "", category = "All") {
  const list = document.getElementById("eventList");
  list.innerHTML = "";
  events.filter(e => 
    (category === "All" || e.category === category) && 
    e.name.toLowerCase().includes(filter.toLowerCase())
  ).forEach(e => {
    const li = document.createElement("li");
    li.innerText = `${e.name} - ${e.category}`;
    list.appendChild(li);
  });
}

document.getElementById("searchInput").addEventListener("keydown", (e) => {
  renderEvents(e.target.value, document.getElementById("categorySelect").value);
});

document.getElementById("categorySelect").addEventListener("change", (e) => {
  renderEvents(document.getElementById("searchInput").value, e.target.value);
});

window.onload = () => renderEvents();