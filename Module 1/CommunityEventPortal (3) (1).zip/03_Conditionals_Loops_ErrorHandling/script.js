const events = [
  { name: "Tree Plantation", date: "2025-07-01", seats: 10 },
  { name: "Blood Donation Camp", date: "2024-12-20", seats: 0 },
  { name: "Health Check-up", date: "2025-08-10", seats: 20 }
];

const upcomingEvents = document.getElementById("eventList");

events.forEach(event => {
  if (new Date(event.date) > new Date() && event.seats > 0) {
    const li = document.createElement("li");
    li.innerText = `${event.name} on ${event.date} (Seats: ${event.seats})`;
    upcomingEvents.appendChild(li);
  }
});