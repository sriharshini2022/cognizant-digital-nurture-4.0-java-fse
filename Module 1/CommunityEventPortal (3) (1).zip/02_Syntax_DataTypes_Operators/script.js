const eventName = "Community Cleanup";
const eventDate = "2025-06-15";
let availableSeats = 25;

availableSeats--;

const eventInfo = `Event: ${eventName}, Date: ${eventDate}, Seats left: ${availableSeats}`;
document.getElementById("event").innerText = eventInfo;