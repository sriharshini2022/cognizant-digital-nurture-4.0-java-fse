document.getElementById("loadBtn").onclick = async () => {
  const loader = document.getElementById("loader");
  const list = document.getElementById("eventList");
  loader.style.display = "block";
  list.innerHTML = "";

  try {
    const response = await new Promise(resolve => setTimeout(() => {
      resolve({ json: () => Promise.resolve([
        { name: "Cleanup Drive" },
        { name: "Food Festival" }
      ]) });
    }, 1500));
    const events = await response.json();
    events.forEach(e => {
      const li = document.createElement("li");
      li.textContent = e.name;
      list.appendChild(li);
    });
  } catch (error) {
    alert("Failed to load events");
  } finally {
    loader.style.display = "none";
  }
};