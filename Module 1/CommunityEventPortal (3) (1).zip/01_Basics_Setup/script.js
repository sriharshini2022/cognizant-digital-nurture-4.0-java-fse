console.log("Welcome to the Community Portal");

window.onload = () => {
  alert("Page loaded successfully!");
};

function registerUser() {
  alert("Thank you for registering!");
}