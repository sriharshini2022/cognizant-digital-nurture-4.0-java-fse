document.getElementById("ajaxForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const username = this.username.value;
  document.getElementById("response").textContent = "Submitting...";
  setTimeout(() => {
    document.getElementById("response").textContent = `Welcome, ${username}! Your registration is received.`;
  }, 1000);
});