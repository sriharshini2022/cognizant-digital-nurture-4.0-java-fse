const events = ["Hackathon", "Workshop", "Cleanup Drive"];
const container = document.getElementById("eventContainer");

events.forEach(name => {
  const div = document.createElement("div");
  div.textContent = name;
  container.appendChild(div);
});