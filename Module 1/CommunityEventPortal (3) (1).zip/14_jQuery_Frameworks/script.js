$(document).ready(function() {
  $("#registerBtn").click(function() {
    $("#eventCard").fadeIn();
  });
});