const events = [
  { title: "Jazz Night", type: "Music" },
  { title: "Tech Talk", type: "Education" },
  { title: "Rock Concert", type: "Music" }
];

const musicEvents = events.filter(e => e.type === "Music");
const formatted = musicEvents.map(e => `<li>${e.title}</li>`).join('');
document.getElementById("eventList").innerHTML = formatted;