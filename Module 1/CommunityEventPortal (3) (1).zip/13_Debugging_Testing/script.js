document.getElementById("debugForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const inputValue = document.getElementById("inputField").value;
  console.log("User input:", inputValue);
  debugger; // Use browser DevTools to inspect this line
});