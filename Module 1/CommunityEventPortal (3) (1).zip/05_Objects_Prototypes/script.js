function Event(name, seats) {
  this.name = name;
  this.seats = seats;
}
Event.prototype.checkAvailability = function() {
  return this.seats > 0;
};

const event1 = new Event("Blood Donation", 0);
const event2 = new Event("Coding Workshop", 5);

const output = document.getElementById("output");
[ event1, event2 ].forEach(e => {
  const p = document.createElement("p");
  p.textContent = `${e.name} - Available: ${e.checkAvailability()}`;
  output.appendChild(p);
});